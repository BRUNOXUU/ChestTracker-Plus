@file:Suppress("UnstableApiUsage", "RedundantNullableReturnType")

import com.github.breadmoirai.githubreleaseplugin.GithubReleaseTask
import me.modmuss50.mpp.ReleaseType
import org.gradle.jvm.tasks.Jar
import org.ajoberstar.grgit.Grgit
import red.jackf.GenerateChangelogTask
import red.jackf.UpdateDependenciesTask

plugins {
    id("maven-publish")
    id("net.fabricmc.fabric-loom") version "1.15-SNAPSHOT"
    id("com.github.breadmoirai.github-release") version "2.5.2"
    id("org.ajoberstar.grgit") version "5.3.0"
    id("io.github.klahap.dotenv") version "1.1.3"
    id("me.modmuss50.mod-publish-plugin") version "0.8.3"
}

val grgit: Grgit? = project.grgit

var canPublish = grgit != null && System.getenv("RELEASE") != null

fun getVersionSuffix(): String {
    return grgit?.branch?.current()?.name ?: "nogit+${properties["minecraft_version"]}"
}

group = properties["maven_group"]!!

if (System.getenv().containsKey("NEW_TAG")) {
    version = System.getenv("NEW_TAG").substring(1)
} else {
    val versionStr = "${properties["mod_version"]}+${properties["minecraft_version"]!!}"
    canPublish = false
    version = if (grgit != null) {
        "$versionStr+dev-${grgit.log()[0].abbreviatedId}"
    } else {
        "$versionStr+dev-nogit"
    }
}

val isBundlingSearchables = properties["bundle_searchables"] == "true"

base {
    archivesName.set("${properties["archives_base_name"]}")
}

repositories {
    // Mod Menu, EMI
    maven {
        name = "TerraformersMC"
        url = uri("https://maven.terraformersmc.com/releases/")
        content {
            includeGroup("com.terraformersmc")
            includeGroup("dev.emi")
        }
    }

    // PB4 / Placeholder API
    maven {
        name = "Nucleoid"
        url = uri("https://maven.nucleoid.xyz/")
        content {
            includeGroup("eu.pb4")
            includeGroup("xyz.nucleoid")
        }
    }

    // YACL
    maven {
        name = "Xander Maven"
        url = uri("https://maven.isxander.dev/releases")
        content {
            includeGroupAndSubgroups("dev.isxander")
            includeGroupAndSubgroups("org.quiltmc")
        }
    }

    // YACL Snapshots
    maven {
        name = "Xander Snapshot Maven"
        url = uri("https://maven.isxander.dev/snapshots")
        content {
            includeGroupAndSubgroups("dev.isxander")
            includeGroupAndSubgroups("org.quiltmc")
        }
    }

    // Searchables
    maven {
        name = "BlameJared"
        url = uri("https://maven.blamejared.com")
        content {
            includeGroupAndSubgroups("com.blamejared.searchables")
        }
    }

    // Dev Utils, Jade
    maven {
        name = "Modrinth Maven"
        url = uri("https://api.modrinth.com/maven")
        content {
            includeGroup("maven.modrinth")
        }
    }

    // JackFredLib and Where Is It: jars taken from the released mod, because
    // the upstream GitHub Packages repositories require a login.
    maven {
        name = "LocalLibs"
        url = uri("local-maven")
        content {
            includeGroupAndSubgroups("red.jackf")
        }
    }

    // Shulker Box Tooltip
    maven {
        name = "MisterPeModder"
        url = uri("https://maven.misterpemodder.com/libs-release/")
        content {
            includeGroupAndSubgroups("com.misterpemodder")
        }
    }

    // Cloth Config
    maven {
        name = "Shedaniel"
        url = uri("https://maven.shedaniel.me")
        content {
            includeGroupAndSubgroups("me.shedaniel")
        }
    }

    // WTHIT
    maven {
        url  = uri("https://maven2.bai.lol")
        content {
            includeGroupAndSubgroups("lol.bai")
            includeGroupAndSubgroups("mcp.mobius.waila")
        }
    }
}

java {
    withSourcesJar()
}

loom {
    splitEnvironmentSourceSets()

    // WTHIT has no 26.3 build yet - temporarily disabled for this port
    sourceSets["client"].java.exclude("red/jackf/chesttracker/impl/compat/mods/wthit/**")

    mods {
        create("chesttracker") {
            sourceSet(sourceSets["client"])
        }
    }

    log4jConfigs.from(file("log4j2.xml"))

    runConfigs.configureEach {
        this.programArgs.addAll("--username JackFred".split(" "))
    }

    accessWidenerPath.set(file("src/client/resources/chesttracker.accesswidener"))
}

dependencies {
    // To change the versions see the gradle.properties file
    minecraft("com.mojang:minecraft:${properties["minecraft_version"]}")
    implementation("net.fabricmc:fabric-loader:${properties["loader_version"]}")

    implementation("net.fabricmc.fabric-api:fabric-api:${properties["fabric-api_version"]}")

    // Where is it
    implementation("red.jackf:whereisit:${properties["where-is-it_version"]}")
    include("red.jackf:whereisit:${properties["where-is-it_version"]}")

    // Server side of /chesttracker scan. It wraps this mod in the singleJar task instead of being nested here.
    implementation(project(":scan"))

    // Config
    implementation("dev.isxander:yet-another-config-lib:${properties["yacl_version"]}") {
        exclude(group = "com.terraformersmc", module = "modmenu")
    }

    // dev util
    //modLocalRuntime("dev.emi:emi-fabric:${properties["emi_version"]}")
    //modLocalRuntime("maven.modrinth:jsst:mc1.20-0.3.12")

    ////////////////
    // MOD COMPAT //
    ////////////////

    // Searchables
    compileOnly("com.blamejared.searchables:Searchables-fabric-${properties["searchables_version"]}") {
        exclude(group = "net.fabricmc.fabric-api", module = "fabric-api")
    }
    runtimeOnly("com.blamejared.searchables:Searchables-fabric-${properties["searchables_version"]}") {
        exclude(group = "net.fabricmc.fabric-api", module = "fabric-api")
    }
    if (isBundlingSearchables) include("com.blamejared.searchables:Searchables-fabric-${properties["searchables_version"]}")

    // Mod Menu
    compileOnly("com.terraformersmc:modmenu:${properties["modmenu_version"]}")
    localRuntime("com.terraformersmc:modmenu:${properties["modmenu_version"]}")

    // Shulker Box Tooltip
    compileOnly("com.misterpemodder:shulkerboxtooltip-fabric:${properties["shulkerboxtooltip_version"]}")

    //runtimeOnly("com.misterpemodder:shulkerboxtooltip-fabric:${properties["shulkerboxtooltip_version"]}")
    //runtimeOnly("me.shedaniel.cloth:cloth-config-fabric:${properties["clothconfig_version"]}")

    // WTHIT
    compileOnly("mcp.mobius.waila:wthit-api:${properties["wthit_version"]}")

    //runtimeOnly("mcp.mobius.waila:wthit:${properties["wthit_version"]}")
    //runtimeOnly("lol.bai:badpackets:${properties["badpackets_version"]}")

    // Jade
    compileOnly("maven.modrinth:jade:${properties["jade_version"]}")
    localRuntime("maven.modrinth:jade:${properties["jade_version"]}")

    // Litematica
    //modCompileOnly("maven.modrinth:litematica:${properties["litematica_version"]}")
    //modCompileOnly("maven.modrinth:malilib:${properties["malilib_version"]}")
    compileOnly(fileTree("libs"))

    //runtimeOnly("maven.modrinth:litematica:${properties["litematica_version"]}")
    //runtimeOnly("maven.modrinth:malilib:${properties["malilib_version"]}")
}

fabricApi {
    configureTests {
        createSourceSet.set(true)
        modId.set("chesttracker-test")
        enableGameTests.set(false)
        enableClientGameTests.set(true)
        eula.set(true)
    }
}

// One jar for clients and servers. The outer mod is the scan component, which loads on both sides. This mod is
// client-only and requires YACL, so it goes inside as a nested jar that a dedicated server skips.
val nestedClientJarName = "chesttracker.jar"
val singleJar = tasks.register<Zip>("singleJar") {
    group = "build"
    val scanJar = project(":scan").tasks.named<Jar>("jar").flatMap { it.archiveFile }
    val clientJar = tasks.named<Jar>("jar").flatMap { it.archiveFile }
    dependsOn(":scan:jar", "jar")

    archiveFileName.set("ChestTrackerMelhor.jar")
    destinationDirectory.set(layout.buildDirectory.dir("libs"))

    from(scanJar.map { zipTree(it) }) {
        filesMatching("fabric.mod.json") {
            filter { line ->
                line.replace("\"environment\": \"*\",",
                    "\"environment\": \"*\",\n  \"jars\": [{ \"file\": \"META-INF/jars/$nestedClientJarName\" }],")
            }
        }
    }
    from(clientJar) {
        into("META-INF/jars")
        rename { nestedClientJarName }
    }
    from("LICENSE")
    // the notice of modification the LGPL asks for
    from("modrinth/changelog.md") {
        rename { "CHANGES-CHEST-TRACKER-MELHOR.md" }
    }
}

tasks.named("build") {
    dependsOn(singleJar)
}

// Checks of the finished jar outside the development environment: ./gradlew prodServer and ./gradlew prodClient
val prodServerMods by configurations.creating { isTransitive = false }
val prodClientMods by configurations.creating { isTransitive = false }

dependencies {
    prodServerMods("net.fabricmc.fabric-api:fabric-api:${properties["fabric-api_version"]}")
    prodClientMods("net.fabricmc.fabric-api:fabric-api:${properties["fabric-api_version"]}")
    prodClientMods("dev.isxander:yet-another-config-lib:${properties["yacl_version"]}")
}

tasks.register<net.fabricmc.loom.task.prod.ServerProductionRunTask>("prodServer") {
    mods.setFrom(singleJar, prodServerMods)
    installerVersion.set("1.1.0")
    loaderVersion.set(properties["loader_version"].toString())
    minecraftVersion.set(properties["minecraft_version"].toString())
    runDir.set(layout.buildDirectory.dir("run/prodServer"))
    programArgs.add("nogui")
}

tasks.register<net.fabricmc.loom.task.prod.ClientProductionRunTask>("prodClient") {
    mods.setFrom(singleJar, prodClientMods)
    runDir.set(layout.buildDirectory.dir("run/prodClient"))
}

tasks.withType<ProcessResources>().configureEach {
    filesMatching("fabric.mod.json") {
        expand(mapOf("version" to version))
    }
}

tasks.withType<JavaCompile>().configureEach {
    options.release.set(25)
}

tasks.jar {
    from("LICENSE") {
        rename { "${it}_${properties["archivesBaseName"]}"}
    }
}

// configure the maven publication
publishing {
    publications {
        create<MavenPublication>("mavenJava") {
            from(components["java"])

            pom {
                name = project.properties["mod_name"].toString()
                description = "Track items across storage blocks"
                url = "https://github.com/ponuing/ChestTracker"
                licenses {
                    license {
                        name = "LGPL-3.0"
                        url = "https://opensource.org/license/lgpl-3-0/"
                    }
                }
                developers {
                    developer {
                        name = "ponuing"
                        url = "https://github.com/ponuing"
                    }
                }
                scm {
                    connection = "scm:git:git://github.com/ponuing/ChestTracker.git"
                    developerConnection = "scm:git:git://github.com/ponuing/ChestTracker.git"
                    url = "https://github.com/ponuing/ChestTracker"
                }
            }
        }
    }

    repositories {
        if (!System.getenv().containsKey("CI")) mavenLocal()

        if (canPublish) {
            maven {
                name = "GitHubPackages"
                url = uri("https://maven.pkg.github.com/ponuing/ChestTracker")
                credentials {
                    username = System.getenv("GITHUB_ACTOR")
                    password = System.getenv("GITHUB_TOKEN")
                }
            }
        }
    }
}

if (canPublish) {
    val lastTag = if (System.getenv("PREVIOUS_TAG") == "NONE") null else System.getenv("PREVIOUS_TAG")
    val newTag = "v$version"

    var generateChangelogTask: TaskProvider<GenerateChangelogTask>? = null

    // Changelog Generation
    if (lastTag != null) {
        val changelogHeader = if (properties.containsKey("changelogHeaderAddon")) {
            val addonProp: String = properties["changelogHeaderAddon"]!!.toString()

            if (addonProp.isNotBlank()) {
                addonProp
            } else {
                null
            }
        } else {
            null
        }

        val changelogFileText = rootProject.file("changelogs/${properties["mod_version"]}.md")
            .takeIf { it.exists() }
            ?.readText()

        generateChangelogTask = tasks.register<GenerateChangelogTask>("generateChangelog") {
            this.lastTag.set(lastTag)
            this.newTag.set(newTag)
            githubUrl.set(properties["github_url"]!!.toString())
            prefixFilters.set(properties["changelog_filter"]!!.toString().split(","))

            val bundledText = if (isBundlingSearchables) {
                """
                |Bundled:
                |  - Where Is It: ${properties["where-is-it_version"]}
                |  - Searchables: ${properties["searchables_version"]}
                |  """.trimMargin()
            } else {
                """
                |Bundled:
                |  - Where Is It: ${properties["where-is-it_version"]}
                |  """.trimMargin()
            }

            // Add a bundled block for each module version
            prologue.set(listOfNotNull(changelogHeader, changelogFileText, bundledText).joinToString(separator = "\n\n"))
        }
    }

    val changelogTextProvider = if (generateChangelogTask != null) {
        provider {
            generateChangelogTask.get().changelogFile.get().asFile.readText()
        }
    } else {
        provider {
            "No Changelog Generated"
        }
    }

    // GitHub Release
    tasks.named<GithubReleaseTask>("githubRelease") {
        generateChangelogTask?.let { dependsOn(it) }

        authorization = System.getenv("GITHUB_TOKEN")?.let { "Bearer $it" }
        owner = properties["github_owner"]!!.toString()
        repo = properties["github_repo"]!!.toString()
        tagName = newTag
        releaseName = "${properties["mod_name"]} $newTag"
        targetCommitish = grgit!!.branch.current().name
        releaseAssets.from(
            tasks["jar"].outputs.files,
            tasks["sourcesJar"].outputs.files,
        )
        subprojects.forEach {
            releaseAssets.from(
                it.tasks["jar"].outputs.files,
                it.tasks["sourcesJar"].outputs.files,
            )
        }

        body = changelogTextProvider
    }

    // Mod Platforms
    if (listOf("CURSEFORGE_TOKEN", "MODRINTH_TOKEN").any { System.getenv().containsKey(it) }) {
        publishMods {
            changelog.set(changelogTextProvider)
            type.set(when(properties["release_type"]) {
                "release" -> ReleaseType.STABLE
                "beta" -> ReleaseType.BETA
                else -> ReleaseType.ALPHA
            })
            modLoaders.add("fabric")
            modLoaders.add("quilt")
            file.set(tasks.named<Jar>("jar").get().archiveFile)

            if (System.getenv().containsKey("CURSEFORGE_TOKEN") || dryRun.get()) {
                curseforge {
                    projectId.set("1368871")
                    accessToken.set(System.getenv("CURSEFORGE_TOKEN"))
                    properties["game_versions_curse"]!!.toString().split(",").forEach {
                        minecraftVersions.add(it)
                    }
                    displayName.set("${properties["prefix"]!!} ${properties["mod_name"]!!} ${version.get()}")
                    listOf("fabric-api", "yacl").forEach {
                        requires {
                            slug.set(it)
                        }
                    }
                    listOf("where-is-it-port").forEach {
                        embeds {
                            slug.set(it)
                        }
                    }
                    listOf("modmenu", "shulkerboxtooltip", "wthit", "jade").forEach {
                        optional {
                            slug.set(it)
                        }
                    }

                    if (isBundlingSearchables) {
                        embeds {
                            slug.set("searchables")
                        }
                    } else {
                        optional {
                            slug.set("searchables")
                        }
                    }
                    clientRequired = true
                    serverRequired = false
                }
            }

            if (System.getenv().containsKey("MODRINTH_TOKEN") || dryRun.get()) {
                modrinth {
                    accessToken.set(System.getenv("MODRINTH_TOKEN"))
                    projectId.set("VC2NohMN")
                    properties["game_versions_mr"]!!.toString().split(",").forEach {
                        minecraftVersions.add(it)
                    }
                    displayName.set("${properties["mod_name"]!!} ${version.get()}")
                    listOf("fabric-api", "yacl").forEach {
                        requires {
                            slug.set(it)
                        }
                    }
                    listOf("where-is-it-port").forEach {
                        embeds {
                            slug.set(it)
                        }
                    }
                    listOf("modmenu", "shulkerboxtooltip", "wthit", "jade").forEach {
                        optional {
                            slug.set(it)
                        }
                    }

                    if (isBundlingSearchables) {
                        embeds {
                            slug.set("searchables")
                        }
                    } else {
                        optional {
                            slug.set("searchables")
                        }
                    }
                }
            }
        }
    }
}

tasks.register<UpdateDependenciesTask>("updateModDependencies") {
    mcVersion.set(properties["minecraft_version"]!!.toString())
    loader.set("fabric")
}
